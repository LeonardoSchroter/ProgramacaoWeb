import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './Components/App.css'
import { useProductData } from './hooks/useProductData'
import { Card } from './Components/Card'

function App() {
  const { data } = useProductData();
    return (
      
      <div className = 'container'>
        <h1>Menu</h1>
        <div className='card-grid'>
          
            {data?.map(ProductData =>
              <Card 
                price={ProductData.price}
                name = {ProductData.name}
                image={ProductData.image}
                description={ProductData.description}
                />
             )}
          
        </div>
      </div>
    )
  }

export default App
