package com.example.MenuStream.repository;

import com.example.MenuStream.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
}
