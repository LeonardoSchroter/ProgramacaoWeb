package com.Trabalho.crud.Service;

import com.Trabalho.crud.Model.Orders;
import com.Trabalho.crud.repository.OrdersRepository;
import com.Trabalho.crud.Resource.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {
    // A referência para o repositório que gerencia as entidades User.
    // A anotação 'final' indica que a referência não pode ser alterada após a construção do objeto.
    @Autowired
    private OrdersRepository ordersRepository;

    // Construtor para injeção de dependência do UserRepository.
    // O Spring injeta automaticamente uma instância de UserRepository quando UserService é criado.
    @Autowired
    public OrderService(OrdersRepository ordersRepository) {
        this.ordersRepository = ordersRepository;
    }

    // Método para criar um novo usuário. Recebe um objeto User e o persiste no banco de dados.
    // Retorna o objeto User salvo, incluindo o ID atribuído automaticamente pelo banco de dados.
    public Orders createOrder(Orders order) {
        return ordersRepository.save(order);
    }

    // Método para encontrar todos os usuários cadastrados no banco de dados.
    // Retorna uma lista de objetos User. Pode ser vazia se nenhum usuário for encontrado.
    public List<Orders> findAllOrders() {
        return ordersRepository.findAll();
    }

    // Método para encontrar um usuário pelo seu ID.
    // Retorna um Optional<User>, que pode ou não conter um objeto User, dependendo se o usuário foi encontrado.
    public Optional<Orders> findOrdersById(int id) {
        return ordersRepository.findById(id);
    }

    // Método para atualizar os dados de um usuário existente, identificado pelo seu ID.
    // Se o usuário com o ID fornecido não for encontrado, uma ResourceNotFoundException será lançada.
    // Retorna o objeto User atualizado.
    public Orders updateOrder(int id, Orders orderDetails) {
        Orders order = ordersRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + id));
        order.setOrderDate(orderDetails.getOrderDate());
        order.setCustomer(orderDetails.getCustomer());
        order.setAmmount(orderDetails.getAmmount());
        order.setPayment(orderDetails.getPayment());
        order.setProducts(orderDetails.getProducts());
        order.setQuantity(orderDetails.getQuantity());
        order.setDeliveryDate(orderDetails.getDeliveryDate());
        order.setDeliveryInstructions(orderDetails.getDeliveryInstructions());
        // A lista de telefones é atualizada assumindo que o setter copia o estado. Em uma aplicação real,
        // você pode precisar de lógica adicional para gerenciar corretamente as relações e evitar problemas
        // como a duplicação de entidades.
        return ordersRepository.save(order);
    }

    // Método para deletar um usuário pelo seu ID.
    // Se o usuário com o ID fornecido não for encontrado, uma ResourceNotFoundException será lançada.
    // Não retorna nenhum valor.
    public void deleteOrder(int id) {
        Orders order = ordersRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + id));
        ordersRepository.delete(order);
    }
}
