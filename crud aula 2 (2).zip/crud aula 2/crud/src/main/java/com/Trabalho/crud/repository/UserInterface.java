package com.Trabalho.crud.repository;

import com.Trabalho.crud.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserInterface extends JpaRepository<User,Integer> {
}
