package com.Trabalho.crud.Model;

import jakarta.persistence.*;

import java.util.List;

public class ShoppingCart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToMany
    @JoinTable(
            name = "shoppingCart_product",
            joinColumns = @JoinColumn(name = "shoppingCartId"),
            inverseJoinColumns = @JoinColumn(name = "productId"))
    private List<Product> produtos;

    @ManyToOne
    @JoinColumn(name = "customerId")
    private Customer customer;

    private int quantities;

    private Double subtotal;
}
