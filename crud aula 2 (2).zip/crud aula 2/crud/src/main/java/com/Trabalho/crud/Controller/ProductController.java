package com.Trabalho.crud.Controller;

import com.Trabalho.crud.Model.Product;
import com.Trabalho.crud.Resource.ResourceNotFoundException;
import com.Trabalho.crud.Service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping(path = "/product")
public class ProductController {
    @Autowired
    private  ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    // Método para criar um novo usuário. Recebe um objeto User no corpo da requisição.
    // Retorna o usuário criado com o status HTTP 200 OK.
    @PostMapping
    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
        Product newUser = productService.createProduct(product);
        return ResponseEntity.ok(newUser);
    }

    // Método para recuperar todos os usuários cadastrados.
    // Retorna uma lista de usuários com o status HTTP 200 OK.
    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = productService.findAllProducts();
        return ResponseEntity.ok(products);
    }

    // Método para buscar um usuário pelo seu ID.
    // Caso o usuário não seja encontrado, lança uma ResourceNotFoundException.
    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable int id) {
        Product product = productService.findProductById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
        return ResponseEntity.ok(product);
    }

    // Método para atualizar um usuário existente pelo ID.
    // Recebe um objeto User com as novas informações no corpo da requisição.
    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable int id, @RequestBody Product productDetails) {
        Product updatedProduct = productService.updateProduct(id, productDetails);
        return ResponseEntity.ok(updatedProduct);
    }

    // Método para deletar um usuário pelo ID.
    // Retorna uma resposta vazia com status HTTP 200 OK.
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable int id) {
        productService.deleteProduct(id);
        return ResponseEntity.ok().build();
    }
}
