package com.Trabalho.crud.repository;

import com.Trabalho.crud.Model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment,Integer> {
}
