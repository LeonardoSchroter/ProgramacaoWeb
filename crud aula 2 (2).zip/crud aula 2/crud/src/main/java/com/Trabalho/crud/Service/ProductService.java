package com.Trabalho.crud.Service;

import com.Trabalho.crud.Model.Product;
import com.Trabalho.crud.Resource.ResourceNotFoundException;
import com.Trabalho.crud.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    // Construtor para injeção de dependência do UserRepository.
    // O Spring injeta automaticamente uma instância de UserRepository quando UserService é criado.
    @Autowired
    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    // Método para criar um novo usuário. Recebe um objeto User e o persiste no banco de dados.
    // Retorna o objeto User salvo, incluindo o ID atribuído automaticamente pelo banco de dados.
    public Product createProduct(Product product) {
        return productRepository.save(product);
    }

    // Método para encontrar todos os usuários cadastrados no banco de dados.
    // Retorna uma lista de objetos User. Pode ser vazia se nenhum usuário for encontrado.
    public List<Product> findAllProducts() {
        return productRepository.findAll();
    }

    // Método para encontrar um usuário pelo seu ID.
    // Retorna um Optional<User>, que pode ou não conter um objeto User, dependendo se o usuário foi encontrado.
    public Optional<Product> findProductById(int id) {
        return productRepository.findById(id);
    }

    // Método para atualizar os dados de um usuário existente, identificado pelo seu ID.
    // Se o usuário com o ID fornecido não for encontrado, uma ResourceNotFoundException será lançada.
    // Retorna o objeto User atualizado.
    public Product updateProduct(int id, Product productdetails) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
        product.setName(productdetails.getName());
        product.setCategory(productdetails.getCategory());
        product.setPrice(productdetails.getPrice());
        product.setOrders(productdetails.getOrders());
        product.setStatus(productdetails.isStatus());
        product.setDescription(productdetails.getDescription());
        // A lista de telefones é atualizada assumindo que o setter copia o estado. Em uma aplicação real,
        // você pode precisar de lógica adicional para gerenciar corretamente as relações e evitar problemas
        // como a duplicação de entidades.
        return productRepository.save(product);
    }

    // Método para deletar um usuário pelo seu ID.
    // Se o usuário com o ID fornecido não for encontrado, uma ResourceNotFoundException será lançada.
    // Não retorna nenhum valor.
    public void deleteProduct(int id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
        productRepository.delete(product);
    }
}
