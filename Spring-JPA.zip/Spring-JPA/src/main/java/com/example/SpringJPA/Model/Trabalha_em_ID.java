package com.example.SpringJPA.Model;

import jakarta.persistence.Embeddable;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Embeddable
public class Trabalha_em_ID implements Serializable {

   @ManyToOne
    private Funcionario fcpf;

    @ManyToOne
    private Projeto pnr;

    // Constructors, getters, setters, etc.
}
