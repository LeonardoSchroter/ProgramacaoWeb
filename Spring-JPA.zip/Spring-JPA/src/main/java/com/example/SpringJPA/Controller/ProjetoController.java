package com.example.SpringJPA.Controller;

import com.example.SpringJPA.Model.Funcionario;
import com.example.SpringJPA.Model.Projeto;
import com.example.SpringJPA.Repository.RepositorioFuncionario;
import com.example.SpringJPA.Repository.RepositorioProjeto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping(
        "projetos"
)
public class ProjetoController {
    @Autowired
    private RepositorioProjeto repository;

    @GetMapping
    public @ResponseBody List<Projeto> listarProjetos(){
        return repository.findAll();
    }

    @PostMapping
    public @ResponseBody String salvarProjeto(@RequestBody Projeto projeto) {
        repository.save(projeto);
        return "saved";
    }
}
