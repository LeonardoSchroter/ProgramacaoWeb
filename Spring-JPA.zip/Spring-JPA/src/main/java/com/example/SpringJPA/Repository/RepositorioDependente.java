package com.example.SpringJPA.Repository;

import com.example.SpringJPA.Model.Dependente;
import com.example.SpringJPA.Model.Dependente_id;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositorioDependente extends JpaRepository<Dependente, Dependente_id> {
}
