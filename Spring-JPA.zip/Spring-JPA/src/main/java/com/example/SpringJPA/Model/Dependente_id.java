package com.example.SpringJPA.Model;

import jakarta.persistence.Embeddable;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import java.io.Serializable;

@Embeddable
public class Dependente_id implements Serializable {

    @ManyToOne
    @JoinColumn(nullable = false)
    private Funcionario funcionario;

    private String nome;

    // Constructors, getters, setters, etc.

}
