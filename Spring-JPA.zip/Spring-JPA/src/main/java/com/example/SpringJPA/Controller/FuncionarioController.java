package com.example.SpringJPA.Controller;


import com.example.SpringJPA.Model.Funcionario;
import com.example.SpringJPA.Repository.RepositorioFuncionario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping(
        "funcionarios"
)
public class FuncionarioController {

    @Autowired
    private RepositorioFuncionario repository;

    @GetMapping
    public @ResponseBody List<Funcionario> listarFuncionarios(){
        return repository.findAll();
    }

    @PostMapping
    public @ResponseBody String salvarFuncionario(@RequestBody Funcionario pessoa) {
        repository.save(pessoa);
        return "saved";
    }
}
