package com.example.SpringJPA.Controller;

import com.example.SpringJPA.Model.Dependente;
import com.example.SpringJPA.Repository.RepositorioDependente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping(
        "dependentes"
)
public class DependenteController {
    @Autowired
    private RepositorioDependente repository;

    @GetMapping
    public @ResponseBody List<Dependente> listarDependentes(){
        return repository.findAll();
    }

    @PostMapping
    public @ResponseBody String salvarDependente(@RequestBody Dependente dependente) {
        repository.save(dependente);
        return "saved";
    }
}
