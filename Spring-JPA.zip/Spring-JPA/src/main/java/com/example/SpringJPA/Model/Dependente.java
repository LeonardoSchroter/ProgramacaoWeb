package com.example.SpringJPA.Model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Dependente {

    @EmbeddedId
    private Dependente_id id;

    @Column(nullable = true)
    private char sexo;

    private String dataNasc;

    private String parentesco;


}
