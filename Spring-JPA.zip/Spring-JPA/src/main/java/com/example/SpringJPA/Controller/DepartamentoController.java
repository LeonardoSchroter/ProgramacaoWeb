package com.example.SpringJPA.Controller;

import com.example.SpringJPA.Model.Departamento;
import com.example.SpringJPA.Model.Dependente;
import com.example.SpringJPA.Repository.RepositorioDepartamento;
import com.example.SpringJPA.Repository.RepositorioDependente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@Controller
@RequestMapping (
    "departamentos"
)
public class DepartamentoController {
    @Autowired
    private RepositorioDepartamento repository;

    @GetMapping
    public @ResponseBody List<Departamento> listarDepartamento(){
        return repository.findAll();
    }

    @PostMapping
    public @ResponseBody String salvarDepartamento(@RequestBody Departamento departamento) {
        repository.save(departamento);
        return "saved";
    }
}
