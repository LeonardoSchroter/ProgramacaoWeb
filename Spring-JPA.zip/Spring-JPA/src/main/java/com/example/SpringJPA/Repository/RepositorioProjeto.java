package com.example.SpringJPA.Repository;

import com.example.SpringJPA.Model.Funcionario;
import com.example.SpringJPA.Model.Projeto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositorioProjeto extends JpaRepository<Projeto,Integer> {
}
